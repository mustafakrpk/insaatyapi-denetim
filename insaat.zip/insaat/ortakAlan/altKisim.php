<div class="footer wow fadeIn" data-wow-delay="0.3s">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 col-lg-3">
                            <div class="footer-contact">
                                <h2>Konum</h2>
                                <p><i class="fa fa-map-marker-alt"></i>Bilecik / Merkez </p>
                                <p><i class="fa fa-phone-alt"></i>+90 511 111 11 11</p>
                                <p><i class="fa fa-envelope"></i>insaatDenetim@bseu.com</p>
                                <div class="footer-social">
                                    <a href=""><i class="fab fa-twitter"></i></a>
                                    <a href=""><i class="fab fa-facebook-f"></i></a>
                                    <a href=""><i class="fab fa-youtube"></i></a>
                                    <a href=""><i class="fab fa-instagram"></i></a>
                                    <a href=""><i class="fab fa-linkedin-in"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-3">
                            <div class="footer-link">
                                <h2>Sayfalar</h2>
                                <a href="index.php" class="nav-item nav-link active">Anasayfa</a>
                                <a href="hakkimizda.php" class="nav-item nav-link">Hakkımızda</a>
                                <a href="servislerimiz.php" class="nav-item nav-link">Hizmetler</a>
                                <a href="iletisim.php" class="nav-item nav-link">İletişim</a>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-3">
                            <div class="newsletter">
                                <h2>
                                Kaliteli inşaatların temelinde doğru denetimler yatar. Biz, inşaat denetim konusunda uzman ekibimizle her zaman yanınızdayız.
                                </h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>