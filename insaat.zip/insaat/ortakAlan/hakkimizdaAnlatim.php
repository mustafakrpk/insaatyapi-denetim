<div class="about wow fadeInUp" data-wow-delay="0.1s">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-5 col-md-6">
                            <div class="about-img">
                                <img src="img/about.jpg" alt="Image">
                            </div>
                        </div>
                        <div class="col-lg-7 col-md-6">
                            <div class="section-header text-left">
                                <p>BŞEÜ - İnşaat Denetim Firmasına Hoşgeldiniz</p>
                                <h2>5 Yıllık Tecrübe</h2>
                            </div>
                            <div class="about-text">
                                <p>
                                BŞEÜ - İnşaat Denetim olarak, 5 yıl boyunca inşaat sektöründe faaliyet gösteriyoruz. Firmamız, inşaat projelerinin her aşamasında denetim yaparak güvenli ve kaliteli yapılar ortaya çıkarmayı hedefler.
                                </p>
                                <p>
                                Müşterilerimize en iyi hizmeti sunmak için, işimizi büyük bir titizlikle yaparız. Çalışanlarımızın tamamı uzman ve deneyimli niteliklere sahiptir. Bu sayede, müşterilerimizin projelerini zamanında ve bütçe dahilinde tamamlarız.
                                </p>
                                <p>
                                BŞEÜ - İnşaat Denetim olarak, müşterilerimiz için en uygun çözümleri bulmayı ve teknolojinin en son yeniliklerini takip etmeyi de önemseriz. Bu sayede, müşterilerimize daha verimli ve kaliteli hizmet sunarız.
                                </p>
                                <p>
                                Detaylı bilgi ve talepleriniz için, web sitemize göz atabilir veya bizimle iletişime geçebilirsiniz.
                                </p>
                                <a class="btn" href="iletisim.php">İletişime Geç</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>