<html>
<head>
    <link rel="stylesheet" type="text/css"
          href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/login.css">
</head>
<body>

<div class="container loginForm">
    <h1>Giriş Yap</h1>
    <form action="loginControl.php" method="post">
        <div class="form-group has-feedback">
            <input type="text" class="form-control form-input" name="kullaniciNo" placeholder="Kullanıcı Adı">
        </div>
        <div class="form-group has-feedback">
            <input type="password" class="form-control form-input" name="sifre" placeholder="Şifre">
        </div>

        <button id="submit" type="submit" class="btn btn-default submit" value="Login">Giriş Yap</button>
    </form>


</div>

</body>
</html>